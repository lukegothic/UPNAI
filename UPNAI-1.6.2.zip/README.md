# UPNAI
Videojuego para enseñar Inteligencia Artificial aplicada a videojuegos en UPNA
